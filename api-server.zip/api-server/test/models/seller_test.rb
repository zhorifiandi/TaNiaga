require 'test_helper'

class SellerTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
