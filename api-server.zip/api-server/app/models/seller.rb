class Seller < ApplicationRecord
  serialize :array_item , Array
  serialize :array_farmer , Array
end
