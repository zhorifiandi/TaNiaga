class Sm < ApplicationRecord
end
