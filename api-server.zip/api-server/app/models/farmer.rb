class Farmer < ApplicationRecord
  serialize :array_product , Array
end
